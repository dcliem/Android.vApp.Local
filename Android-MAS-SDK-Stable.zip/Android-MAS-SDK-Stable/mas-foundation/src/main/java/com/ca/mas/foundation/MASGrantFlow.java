/*
 * Copyright (c) 2016 CA. All rights reserved.
 *
 * This software may be modified and distributed under the terms
 * of the MIT license.  See the LICENSE file for details.
 *
 */

package com.ca.mas.foundation;

import android.support.annotation.IntDef;

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;

@Retention(RetentionPolicy.SOURCE)
@IntDef(value = {MASConstants.MAS_GRANT_FLOW_CLIENT_CREDENTIALS, MASConstants.MAS_GRANT_FLOW_PASSWORD})
public @interface MASGrantFlow {
}

